# -*-coding=gbk-*-

class Lin:
    def __init__(self, root, dir):
        self.filelist = []
        self.locatelist = []
        print root+dir

        self.file = root+dir
        count = 0
        f = open(self.file,'r')
        for line in f:
            count += 1
            self.filelist.append(line)
            if 'CreatedByG' in line:
                self.locatelist.append(count)
        self.locatelist.append(count)
        f.close()
