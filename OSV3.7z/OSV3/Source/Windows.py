# -*-coding=gbk-*-
from docx import Document
import re

class Win:

    checkresult = [''] * 32

    def __init__(self,root,dir):
        self.filelist = []
        self.locatelist = []
        self.resultlist = [''] * 31
        self.checklist = []
        self.IP = '0.0.0.0'
        self.file = root + dir + '/' + dir

        f = open(self.file,'r')
        count = 0
        for line in f:
            count += 1
            self.filelist.append(line)
            if 'CreatedbyG' in line:
                self.locatelist.append(count)
        self.locatelist.append(count)
        f.close()

    def read_systeminfo(self):
        for i in range(self.locatelist[0],self.locatelist[1]-1):
            if u'OS ����' in unicode(self.filelist[i], "gbk"):
                self.resultlist[1] = self.filelist[i].split(':')[1].strip(' ')
        self.resultlist[29] = '��Ϊ���� Windows ����ͷ�������DEP'
        self.resultlist[30] += 'δ���������ָ�ʱʹ�����뱣��(���Ϲ�)\n'

    def read_ipconfig(self):
        for i in range(self.locatelist[1],self.locatelist[2]-1):
            if u'IPv4' in unicode(self.filelist[i], "gbk"):
                self.resultlist[0] = re.findall(r"(\d*\.\d*\.\d*\.\d*)", self.filelist[i])[0]
        self.IP = self.resultlist[0]

    def read_secedit(self):
        audit = {'0':'�����(���Ϲ�)','1':'�ɹ�(���Ϲ�)','2':'ʧ��(���Ϲ�)','3':'�ɹ���ʧ��',}
        for i in range(self.locatelist[6],self.locatelist[7]-1):
            if '=' in self.filelist[i]:
                str = self.filelist[i].split('=')[0].strip(' ')
                res = self.filelist[i].split('=')[1].strip(' ').strip('\n')
                if str == 'PasswordComplexity':
                    if res == '0':
                        self.resultlist[5] = 'δ����(���Ϲ�)'
                    else:
                        self.resultlist[5] = '������'
                elif str == 'MinimumPasswordLength':
                    self.resultlist[6] = res
                    if int(res) < 8:
                        self.resultlist[6] += "(���Ϲ�)"
                elif str == 'MaximumPasswordAge':
                    self.resultlist[7] = res
                    if int(res) > 90:
                        self.resultlist[7] += "(���Ϲ�)"
                elif str == 'PasswordHistorySize':
                    self.resultlist[8] = res
                    if int(res) < 5:
                        self.resultlist[8] += "(���Ϲ�)"
                elif str == 'LockoutBadCount':
                    self.resultlist[9] = res
                    if int(res) > 6 or int(res) == 0:
                        self.resultlist[9] += "(���Ϲ�)"
                elif str == 'SeRemoteShutdownPrivilege':
                    self.resultlist[10] = res.replace('*S-1-5-32-544','Administrators').replace('*S-1-1-0','Everyone').replace('*S-1-5-32-545','Users').replace('*S-1-5-32-547','Users').replace('S-1-5-32-551','Backup Operators')
                    if res != '*S-1-5-32-544':
                        self.resultlist[9] += "(���Ϲ�)"
                elif str == 'SeTakeOwnershipPrivilege':
                    self.resultlist[11] = res.replace('*S-1-5-32-544','Administrators').replace('*S-1-1-0','Everyone').replace('*S-1-5-32-545','Users').replace('*S-1-5-32-547','Users').replace('S-1-5-32-551','Backup Operators')
                    if res != '*S-1-5-32-544':
                        self.resultlist[11] += "(���Ϲ�)"

                elif str == 'AuditPolicyChange':
                    self.resultlist[12] = audit[res]
                elif str == 'AuditAccountLogon':
                    self.resultlist[13] = audit[res]
                elif str == 'AuditObjectAccess':
                    self.resultlist[14] = audit[res]
                elif str == 'AuditProcessTracking':
                    self.resultlist[15] = audit[res]
                elif str == 'AuditDSAccess':
                    self.resultlist[16] = audit[res]
                elif str == 'AuditPrivilegeUse':
                    self.resultlist[17] = audit[res]
                elif str == 'AuditSystemEvents':
                    self.resultlist[18] = audit[res]
                elif str == 'AuditAccountManage':
                    self.resultlist[19] = audit[res]

    def read_software(self):
        isfound = False
        for i in range(self.locatelist[5], self.locatelist[6] - 1):
            if '360Safe' in self.filelist[i]:
                self.resultlist[24] += '360Safe,'
                isfound = True
            if 'Symantec AntiVirus' in self.filelist[i]:
                self.resultlist[24] += 'Symantec,'
                isfound = True
        if isfound == False:
            self.resultlist[24] += '(���Ϲ�)'

    def read_users(self):
        for i in range(self.locatelist[7], self.locatelist[8] - 1):
            if u'�û���' in unicode(self.filelist[i], "gbk") :
                name = self.filelist[i].split('               ')[1].strip(' ').strip('\n') + ','
                if u'Yes' in unicode(self.filelist[i+5], "gbk"):
                    self.resultlist[4] += name
        if 'Administrator' in self.resultlist[4]:
            self.resultlist[2] = 'δ����(���Ϲ�)'
        else:
            self.resultlist[2] = '�Ѹ���'
        if 'Guest' in self.resultlist[4]:
            self.resultlist[3] = 'δ����(���Ϲ�)'
        else:
            self.resultlist[3] = '�ѽ���'

    def read_regedit(self):
        for i in range(self.locatelist[8], self.locatelist[9] - 1):
            if u'�Զ�����' in unicode(self.filelist[i], "gbk"):
                if 'oxff' in unicode(self.filelist[i+1], "gbk"):
                    self.resultlist[22] = '�ѹر�'
                else:
                    self.resultlist[22] = 'δ����(���Ϲ�)'
            if u'����ǽ״̬' in unicode(self.filelist[i], "gbk"):
                if '0x0' in unicode(self.filelist[i+1], "gbk"):
                    self.resultlist[21] = 'δ����(���Ϲ�)'
                else:
                    self.resultlist[21] = '�ѿ���'
            if u'Զ��Э��' in unicode(self.filelist[i], "gbk"):
                if '0x0' in unicode(self.filelist[i+1], "gbk"):
                    self.resultlist[27] = '�ѹر�'
                else:
                    self.resultlist[27] = '�ѿ���(���Ϲ�)'
            if u'Զ������' in unicode(self.filelist[i], "gbk"):
                if '0x1' in unicode(self.filelist[i+1], "gbk"):
                    self.resultlist[28] = '�ѹر�'
                else:
                    self.resultlist[28] = '�ѿ���(���Ϲ�)'
            if u'��������' in unicode(self.filelist[i], "gbk"):
                if '0x0' in unicode(self.filelist[i+1], "gbk"):
                    self.resultlist[25] += "�����������ѹر�\n"
                else:
                    self.resultlist[25] += "����������δ�ر�(���Ϲ�)\n"
            if u'ADMIN����' in unicode(self.filelist[i], "gbk"):
                if '0x0' in unicode(self.filelist[i+1], "gbk"):
                    self.resultlist[25] += "ADMIN�������ѹر�\n"
                else:
                    self.resultlist[25] += "ADMIN������δ�ر�(���Ϲ�)\n"
            if u'IPC����' in unicode(self.filelist[i], "gbk"):
                if '0x1' in unicode(self.filelist[i+1], "gbk"):
                    self.resultlist[25] += "IPC�������ѹر�\n"
                else:
                    self.resultlist[25] += "IPC������δ�ر�(���Ϲ�)\n"
            if u'REG_MULTI_SZ' in unicode(self.filelist[i], "gbk"):
                self.resultlist[26] += self.filelist[i].split('REG_MULTI_SZ')[0].strip(' ') + ','
            if u'ScreenSaveTimeOut' in unicode(self.filelist[i], "gbk"):
                self.resultlist[30] += 'ʱ�䣺' + self.filelist[i].split('REG_SZ')[1].strip(' ').strip('\n') + '��\n'
            if u'ScreenSaverIsSecure' in unicode(self.filelist[i], "gbk"):
                if self.filelist[i].split('REG_SZ')[1].strip(' ').strip('\n') == '1':
                    self.resultlist[30] = self.resultlist[30].split('\n')[1] + '\n�ѿ��������ָ�ʱʹ�����뱣��'
                else:
                    self.resultlist[30] += 'δ���������ָ�ʱʹ�����뱣��(���Ϲ�)'
            if u'Ӧ����־�ļ���С' in unicode(self.filelist[i], "gbk"):
                self.resultlist[20] += 'Ӧ����־�ļ���С��'+ self.filelist[i+1].split('REG_DWORD')[1].strip(' ').strip('\n')
                if int(self.filelist[i+1].split('REG_DWORD')[1].strip(' '),16) < 41943040:
                    self.resultlist[20] += '(���Ϲ�)\n'
                else:
                    self.resultlist[20] += '\n'
                if '0x0' in self.filelist[i+3]:
                    self.resultlist[20] += '���¼���־����Сʱ��' + '����Ҫ�����¼������¼����ȣ�\n'
                else:
                    self.resultlist[20] += '���¼���־����Сʱ��' + '(���Ϲ�)\n'
            if u'��ȫ��־�ļ���С' in unicode(self.filelist[i], "gbk"):
                self.resultlist[20] += '��ȫ��־�ļ���С��'+ self.filelist[i+1].split('REG_DWORD')[1].strip(' ').strip('\n')
                if int(self.filelist[i+1].split('REG_DWORD')[1].strip(' '),16) < 41943040:
                    self.resultlist[20] += '(���Ϲ�)\n'
                else:
                    self.resultlist[20] += '\n'
                if '0x0' in self.filelist[i+3]:
                    self.resultlist[20] += '���¼���־����Сʱ��' + '����Ҫ�����¼������¼����ȣ�\n'
                else:
                    self.resultlist[20] += '���¼���־����Сʱ��' + '(���Ϲ�)\n'
            if u'ϵͳ��־�ļ���С' in unicode(self.filelist[i], "gbk"):
                self.resultlist[20] += 'ϵͳ��־�ļ���С��'+ self.filelist[i+1].split('REG_DWORD')[1].strip(' ').strip('\n')
                if int(self.filelist[i+1].split('REG_DWORD')[1].strip(' '),16) < 41943040:
                    self.resultlist[20] += '(���Ϲ�)\n'
                else:
                    self.resultlist[20] += '\n'
                if '0x0' in self.filelist[i+3]:
                    self.resultlist[20] += '���¼���־����Сʱ��' + '����Ҫ�����¼������¼����ȣ�'
                else:
                    self.resultlist[20] += '���¼���־����Сʱ��' + '(���Ϲ�)'

    def read_update(self):
        date = open(self.file+'.updatelog','r')
        lines = date.readlines()
        self.resultlist[23] = lines[-1].split('	')[0]
        date.close()

    def docx(self):
        doc = Document(".\\Template\\Windows.docx")
        doc.paragraphs[0].text = self.IP + ':'
        t = doc.tables[0]
        count = 0
        for row in t.rows:
            if  count == 0:
                count += 1
                pass
            elif count == 32:
                break
            else:
                row.cells[2].text = unicode(self.resultlist[count-1].strip('\n'),'gbk')
                count += 1
        try:
            doc.save('.\\Result\\Windows\\'+self.IP+'.docx')
        except IOError :
            print "��ر�Word����ļ�"

    def check(self):
        for i in range(0,31):
            if u'���Ϲ�' in unicode(self.resultlist[i], "gbk"):
                self.checklist.append(i)

    def result(self):
        for i in self.checklist:
            self.checkresult[int(i)] += self.IP + '\n'

    def resultdocx(self):
        doc = Document(".\\Template\\Windows-result.docx")
        t = doc.tables[0]
        count = 0
        for row in t.rows:
            if  count == 0:
                count += 1
                pass
            elif count == 32:
                break
            else:
             row.cells[2].text = unicode(self.checkresult[count+1][:-1],'gbk')
             count += 1
        try:
            doc.save('.\\Result\\Win-result.docx')
        except IOError :
            print "��ر�Word����ļ�"

    def creat(self):
        self.read_systeminfo()
        self.read_ipconfig()
        self.read_software()
        self.read_secedit()
        self.read_users()
        self.read_regedit()
        self.read_update()
        self.docx()
        self.check()
        self.result()
        self.resultdocx()


