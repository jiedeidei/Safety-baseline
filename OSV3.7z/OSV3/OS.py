# -*-coding=gbk-*-
from  sys import path
path.append(r'./Source')
import os
import Windows
import Linux

Wrootdir="./Raw/Windows/"
for root, dirs, files in os.walk(Wrootdir):
    for dir in dirs:
        pc = Windows.Win(root,dir)
        pc.creat()
'''
Lrootdir="./Raw/Linux/"
for root, dirs, files in os.walk(Lrootdir):
    for file in files:
        lin = Linux.Lin(root,file)
'''